import UIKit

func countHi(input : String) -> Int {
    
    let daString = input.lowercased()
        
    let store = daString.components(separatedBy: "hi")
    print(store)
    
    let times = store.count-1
    
    return times
}

func endOther(inOne : String, inTwo : String) -> Bool {
    
    if inOne.hasSuffix(inTwo) { return true
    }

    if inTwo.hasSuffix(inOne) { return true
    }

    return false
}

func sumNumbers(input : String) -> Int {
    var sum : Int = 0
    
    let store = input.components(separatedBy: CharacterSet.decimalDigits.inverted)
    for value in store {
        if(value != ""){
            sum = (Int(value) ?? 0) + sum
        }
    }
    
    return sum
}

// print(countHi(input: "hiOKhiHIYES"))

// print(endOther(inOne: "Hiabc", inTwo: "abc"))

// print(sumNumbers(intput : "Joe34Yes22"))
